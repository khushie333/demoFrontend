const TYPES = {
	UserService: Symbol.for('UserService'),
	CarService: Symbol.for('CarService'),
}

export default TYPES

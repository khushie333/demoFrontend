import mongoose from 'mongoose'
import express, { Application } from 'express'
import cors from 'cors'

import userRoutes from './routes/user.routes'
import authenticateRoutes from './routes/authentication.routes'
import emailRoutes from './routes/email.routes'

import { AppConfig } from './config/connectDB'

const appConfig = new AppConfig()
appConfig.initialize()

//const app = express()
const app: Application = express()
app.use(express.json())

app.use(cors())

// Or, enable CORS for specific origins
// Replace 'http://localhost:3000' with the origin of your frontend application
app.use(cors({ origin: 'http://localhost:3000' }))

const mongoUrl = appConfig.getMongoUrl()

const serverPort = appConfig.getServerPort()

// Connecting to MongoDB cluster
mongoose
	.connect(mongoUrl)
	.then(() => {
		console.log('MongoDB connected successfully')
	})
	.catch((error) => {
		console.error('Error connecting to MongoDB:', error)
	})

const port = process.env.PORT || serverPort // Used the serverPort retrieved from the AppConfig
app.listen(port, () => {
	console.log(`Server is running on port ${port}`)
})

app.use('/api', userRoutes)
app.use('/api', authenticateRoutes)

// Mount emailRoutes without authenticateUser middleware
app.use('/api', emailRoutes)

export default app
